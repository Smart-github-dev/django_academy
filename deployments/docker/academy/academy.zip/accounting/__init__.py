default_app_config = 'accounting.apps.AccountingConfig'
