pip intall -r
```
brew install mysql
```

To run the app run following command
```
python manage.py migrate --run-syncdb && python manage.py runserver 0.0.0.0:8000
```
