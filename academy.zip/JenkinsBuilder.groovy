@Library('CommonLib@master') _
def common = new com.lib.JenkinsCommonDockerBuildPipeline()
common.runPipeline()
