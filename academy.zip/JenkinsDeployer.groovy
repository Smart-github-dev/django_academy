@Library('CommonLib@master') _
def common = new com.lib.JenkinsCommonDeployPipeline()
common.runPipeline()
