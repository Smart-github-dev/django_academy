<!-- Modal create -->

<div id="modal" class="academy-modal">
	<div class="modal-content-wrapper">
		<div class="modal-header d-flex align-items-center justify-content-center">
			<!-- modal header content -->
		</div>
		<div class="modal-body">
			<!-- modal body content -->
		</div>
	</div>
</div>

<!-- ------------------------------------------------------------------------------- -->

<!-- Alert create -->

<div class="alert" id="alert">
  <div class="header-logo">
    <a href="/">
      <img src="/static/images/fuchi_hoz_rgb-white 2.png" alt="Logo">
    </a>
    <span class="close-btn" onclick="document.querySelector('.alert').style.display='none';">&times;</span>
  </div>
  <div class="alert-content">
   <!-- alert message -->
  </div>
</div>

<!-- ------------------------------------------------------------------------------- -->

<!-- Left Menu create -->

<div id="left_menu" class="left-menu">
  <div class="left-side" id="open_left">
    <ul id="user-options" class='dropdown'>
      <li>
        <!-- menu content -->
       </li>
    </ul>
    </div>
</div>

<!-- ------------------------------------------------------------------------------- -->

<!-- Page container create -->

<div id="right-content" class="page-container">
  <div class="right-side">
    <!-- page content -->
  </div>
</div>

<!-- ------------------------------------------------------------------------------- -->

<!-- Card create -->

<div class="card">
  <div class="card-title">
    <h5>
      <!-- card title -->
    </h5>
  </div>
  <div class="card-content">
      <!-- card content -->
  </div>
</div>

<!-- ------------------------------------------------------------------------------- -->

<!-- Form create -->

<form action="/login" method="post">
  <div class="form-group">
  </div>
  <div class="form-group">
  </div>
</form>

<!-- ------------------------------------------------------------------------------- -->

<!-- Input create -->

<input type="text" class="form-control" />

<!-- ------------------------------------------------------------------------------- -->

<!-- Button create -->

<button class="btn bg-info">name</button>
